import { DialogProps } from 'fnx-ui/lib/dialog';
import React from 'react';
import imgAvatarRound from '../../assets/avatar-round.png';
import dialogPointImg from '../../assets/dialog-point.png';
import noneTitleBg from '../../assets/dialog-prize-none.png';
import winTitleBg from '../../assets/dialog-prize-win.png';
import { GAME_CARD_LIST } from '../../core/config';
import { CM, GameCard } from '../../core/interfaces';
import { classnames, createBEM } from '../../utils/class-utils';
import { createFC } from '../../utils/react-utils';
import GameDialog from '../GameDialog';
import './index.less';

interface CProps extends DialogProps {
	prize?: CM.DrawPrizeResult;
}

const bem = createBEM('prize-dialog');

const PrizeDialog = createFC<CProps>('PrizeDialog', ({ className, prize, ...props }) => {
	const theme = (
		<div className={bem('theme')}>
			<img src={prize?.prizeType !== 0 ? winTitleBg : noneTitleBg} />
		</div>
	);

	const renderCoupon = () => {
		const coupon = prize?.couponInfo || {};

		return (
			<>
				<p className={bem('title')}>恭喜你抓到超值优惠券</p>
				<div className={bem('coupon')}>
					<div className={bem('coupon-label')}>优惠券</div>
					<div className={bem('coupon-sep')}>
						<i />
					</div>
					<div className={bem('coupon-body')}>
						<img className={bem('coupon-img')} src={coupon.prizeImg || imgAvatarRound} />
						<div className={bem('coupon-content')}>
							<p className={bem('coupon-name')}>{coupon.couponName}</p>
							<p className={bem('coupon-desc')}>{coupon.couponInfo}</p>
						</div>
					</div>
				</div>
				<p className={bem('coupon-tip')}>优惠券请至【我的】-【优惠券】中查看</p>
			</>
		);
	};

	const renderPoint = () => {
		const point = prize?.pointsInfo;

		return (
			<>
				<p className={bem('title')}>恭喜你抓中大润发积分【{point?.points}】</p>

				<div className={bem('halo')}>
					<img className={bem('halo-point')} src={dialogPointImg} />
				</div>

				<p className={bem('tip')}>积分请至 【我的】-【积分】中查看</p>
			</>
		);
	};

	const renderCard = () => {
		const cardType = prize?.cardInfo?.cardType;

		const card: GameCard | undefined = GAME_CARD_LIST[GAME_CARD_LIST.findIndex((c) => c.type === cardType)];

		return (
			<>
				<p className={bem('title')}>恭喜你抓到一张【{card?.name}】</p>

				<div className={bem('halo')}>
					<img className={bem('halo-card')} src={card?.imageURL} />
				</div>
			</>
		);
	};

	const renderNone = () => {
		return (
			<>
				<p className={bem('title')}>哎呀 ！手滑了，什么都没抓到～</p>
			</>
		);
	};

	return (
		<GameDialog
			{...props}
			className={classnames(bem(), className)}
			title={theme}
			confirmText={(prize?.prizeTimes || 0) > 0 ? '继续玩' : '去集游戏次数'}
			bodyProps={{ className: bem('body') }}
		>
			<div className={bem('content')}>
				{prize?.prizeType === 0 && renderNone()}
				{prize?.prizeType === 1 && renderCoupon()}
				{prize?.prizeType === 2 && renderCard()}
				{prize?.prizeType === 3 && renderPoint()}
				<p className={bem('remain')}>(剩余{prize?.prizeTimes}次)</p>
			</div>
		</GameDialog>
	);
});

export default PrizeDialog;
