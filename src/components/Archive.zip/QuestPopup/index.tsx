import { Button, Toast } from 'fnx-ui';
import { ButtonProps } from 'fnx-ui/lib/button';
import { PopupProps } from 'fnx-ui/lib/popup';
import React, { useRef } from 'react';
import questInviteIcon from '../../assets/quest-invite-icon.png';
import questOrderIcon from '../../assets/quest-order-icon.png';
import questViewIcon from '../../assets/quest-view-icon.png';
import { GAME_CMS_AID, PROJECT_PATHS, PROJECT_ROUTE_BASE } from '../../core/config';
import { RunningEnv } from '../../core/constants';
import { CM } from '../../core/interfaces';
import { useAsyncFn } from '../../hooks/use-advanced';
import { useErrorHandler } from '../../hooks/use-error-handler';
import backendService from '../../services/backend-service';
import cmsService from '../../services/cms-service';
import { classnames, createBEM } from '../../utils/class-utils';
import { appendQuery } from '../../utils/history-utils';
import { NativeWechatShareInfo, NATIVE_BRIDGE } from '../../utils/native-utils';
import { PLATFORM_BRIDGE } from '../../utils/platform-utils';
import { createFC } from '../../utils/react-utils';
import GamePopup from '../GamePopup';
import './index.less';

interface CProps extends PopupProps {
	userAct?: CM.UserActInfo;
	storeCode?: string;
	actId?: number;
	mainPageId?: string | number;
	userNickname?: string;
	userAvatar?: string;
	onShowShareTip?: () => void;
}

const bem = createBEM('quest-popup');

const QuestPopup = createFC<CProps>(
	'QuestPopup',
	({ className, userAct, storeCode, userNickname, userAvatar, actId, mainPageId, onShowShareTip, ...props }) => {
		const [handleError] = useErrorHandler();
		const shareTokenRef = useRef<string>();

		const viewTimes = userAct?.viewTimes || 0;
		const orderTimes = userAct?.orderTimes || 0;
		const helperTimes = userAct?.helperTimes || 0;

		const [{ loading: applyTokenLoading }, { run: handleApplyToken }] = useAsyncFn(
			async (options: {
				storeCode: string;
				guid: string;
				guidMd5: string;
				actId: number;
				userNickname?: string;
				userAvatar?: string;
			}): Promise<[RunningEnv, string]> => {
				const { storeCode, guid, guidMd5, actId, userNickname, userAvatar } = options;

				const token =
					shareTokenRef.current ||
					(await backendService.getShareToken({
						storeCode,
						memGuid: guid,
						memMd5: guidMd5,
						memName: userNickname,
						memAvatar: userAvatar,
						tokenId: `${actId}`,
						tokenType: 1,
					}));

				shareTokenRef.current = token;

				const env = await PLATFORM_BRIDGE.getRunningEnv();

				return [env, token];
			},
			{
				onSuccess: (res, [{ storeCode }]) => {
					const [runningEnv, token] = res;

					// 设置分享
					const shareUrl = `${PROJECT_PATHS.project}${PROJECT_ROUTE_BASE}/inflow/${token}`;

					if (runningEnv === RunningEnv.WeApp) {
						PLATFORM_BRIDGE.postMessage({
							title: '快来参与抓娃娃赢惊喜好礼！！',
							src: appendQuery('pages/www/cms', {
								f: shareUrl,
								aid: GAME_CMS_AID,
								sid: storeCode,
							}),
						});

						onShowShareTip?.();
					} else if (runningEnv === RunningEnv.Ios || runningEnv === RunningEnv.Android) {
						const shareInfo: NativeWechatShareInfo = {
							shareTitle: '快来参与抓娃娃赢惊喜好礼！！',
							shareContent: '',
							shareContentUrl: 'https://yxsale.feiniu.com/act/htm/about-youxian.html',
							shareImageUrl:
								'https://img17.fn-mart.com/pic/fccb134a3cb9210b476f/K26z225zF2tMBlUdl2/s9maoaWy3GB9oR/CtCLmGLWRuyAECTnAAGSYSL-3XE721.jpg',
							smallTalkId: 'gh_5a75412a617c',
							smallTalkPath: appendQuery('/pages/www/cms', {
								f: shareUrl,
								aid: GAME_CMS_AID,
								sid: storeCode,
							}),
						};

						NATIVE_BRIDGE.wechatShare({
							...shareInfo,
							shareTarget: 'frineds',
						});

						props.onClose?.();
					} else {
						Toast.show('该渠道暂不支持分享');
						props.onClose?.();
					}
				},
				onError: (err) => handleError(err),
			},
		);

		const [{ loading: toOrderAddLoading }, { run: handleToOrderAdd }] = useAsyncFn(
			async (params: { storeCode: string; guid: string; guidMd5: string; actId: number }) =>
				backendService.toOrderAdd({
					storeCode: params.storeCode,
					memGuid: params.guid,
					memMd5: params.guidMd5,
					actId: params.actId,
				}),
			{
				onSuccess: () => {
					PLATFORM_BRIDGE.jumpIndex();
					props.onClose?.();
				},
				onError: (err) => handleError(err),
			},
		);

		const renderExtra = (count: number, buttonProps: ButtonProps) => {
			if (count > 0) {
				return <span className={bem('quest-finished')}>已完成</span>;
			}

			return (
				<Button
					className={bem('quest-btn')}
					shape="round"
					size="sm"
					color="linear-gradient(90deg, #FF4ACF 0%, #9D7AF6 100%)"
					{...buttonProps}
				/>
			);
		};

		return (
			<GamePopup {...props} title="做任务集抓娃娃次数" className={classnames(bem(), className)}>
				<ul className={bem('quest-list')}>
					<li className={bem('quest')}>
						<div className={bem('quest-extra')}>
							{renderExtra(helperTimes, {
								children: '去邀请',
								loading: applyTokenLoading,
								onClick: () => {
									const guid = userAct?.memGuid;
									const guidMd5 = userAct?.memMd5;

									cmsService.bp({
										page_id: '234',
										page_col: '165118',
										track_type: '2',
									});

									if (storeCode == null || guid == null || guidMd5 == null || actId == null) {
										Toast.show('邀请失败');
										return;
									}

									handleApplyToken({
										storeCode,
										guid,
										guidMd5,
										actId,
										userNickname,
										userAvatar,
									});
								},
							})}
						</div>
						<div className={bem('quest-content')}>
							<p className={bem('quest-title')}>
								<img className={bem('quest-icon')} src={questInviteIcon} />
								<span>邀请好友助力（{helperTimes}/1）</span>
							</p>
							<p className={bem('quest-desc')}>邀请1名好友助力成功可增加1次机会</p>
						</div>
					</li>
					<li className={bem('quest')}>
						<div className={bem('quest-extra')}>
							{renderExtra(viewTimes, {
								children: '去浏览',
								onClick: () => {
									cmsService.bp({
										page_id: '234',
										page_col: '165117',
										track_type: '2',
									});

									if (mainPageId == null || storeCode == null || actId == null) {
										Toast.show('浏览失败');
										return;
									}

									PLATFORM_BRIDGE.jumpCms({
										url: appendQuery(`${PROJECT_PATHS.cmsSale}/cmsfront/index.html`, {
											ref: actId,
										}),
										aid: `${mainPageId}`,
										sid: storeCode,
									});

									props.onClose?.();
								},
							})}
						</div>
						<div className={bem('quest-content')}>
							<p className={bem('quest-title')}>
								<img className={bem('quest-icon')} src={questViewIcon} />
								<span>浏览会场（{viewTimes}/1）</span>
							</p>
							<p className={bem('quest-desc')}>浏览会场15秒可增加1次机会</p>
						</div>
					</li>
					<li className={bem('quest')}>
						<div className={bem('quest-extra')}>
							{renderExtra(0, {
								// 下单不用显示完成，即可以下单多次
								children: '去下单',
								loading: toOrderAddLoading,
								onClick: () => {
									const guid = userAct?.memGuid;
									const guidMd5 = userAct?.memMd5;

									cmsService.bp({
										page_id: '234',
										page_col: '165094',
										track_type: '2',
									});

									if (storeCode == null || guid == null || guidMd5 == null || actId == null) {
										Toast.show('跳转下单失败');
										return;
									}

									handleToOrderAdd({
										storeCode,
										guid,
										guidMd5,
										actId,
									});
								},
							})}
						</div>
						<div className={bem('quest-content')}>
							<p className={bem('quest-title')}>
								<img className={bem('quest-icon')} src={questOrderIcon} />
								<span>下单（{orderTimes}）</span>
							</p>
							<p className={bem('quest-desc')}>任意下单并签收成功可增加1次机会</p>
						</div>
					</li>
				</ul>
			</GamePopup>
		);
	},
);

export default QuestPopup;
