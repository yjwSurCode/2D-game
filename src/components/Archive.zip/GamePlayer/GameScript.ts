import { Attrs, Group, Layer, Node, Rect, Sprite } from 'spritejs';
import { Class } from 'type-fest';

export abstract class GameScript {
	protected _zIndex = 0;
	protected _nodes: Node[] = [];
	protected abstract layer: Layer;

	protected zIndex(zIndex = 0): number {
		return this._zIndex + zIndex;
	}

	private createNode<T extends Node>(clz: Class<T>, attrs: Partial<Attrs>): T {
		const node = new clz({
			...attrs,
			zIndex: this.zIndex(attrs.zIndex || 0),
		});

		this._nodes.push(node);
		return node;
	}

	protected createSprite(attrs: Partial<Attrs>): Sprite {
		return this.createNode(Sprite, attrs);
	}

	protected createRect(attrs: Partial<Attrs>): Rect {
		return this.createNode(Rect, attrs);
	}

	protected createGroup(attrs: Partial<Attrs>): Group {
		return this.createNode(Group, attrs);
	}

	protected renderSprite(attrs: Partial<Attrs>): Sprite {
		return this.layer.appendChild(this.createSprite(attrs));
	}

	protected renderRect(attrs: Partial<Attrs>): Sprite {
		return this.layer.appendChild(this.createRect(attrs));
	}

	protected renderGroup(attrs: Partial<Attrs>): Group {
		return this.layer.appendChild(this.createGroup(attrs));
	}

	protected remove(node: Node) {
		this._nodes = this._nodes.filter((n) => n !== node);
		node.remove();
	}

	destroy() {
		for (const node of this._nodes) {
			node.remove();
		}
	}
}
