import { Layer } from 'spritejs';
import { noop } from '../../utils/misc-utils';
import { GamePlayer } from './GamePlayer';
import { GameScript } from './GameScript';

export class GameHelp extends GameScript {
	protected layer: Layer;

	onHelpBtnClick: () => void = noop;

	constructor(private player: GamePlayer, options: { zIndex: number; layer: Layer }) {
		super();
		this._zIndex = options.zIndex;
		this.layer = options.layer;
	}

	setup() {
		// nothing
	}

	start() {
		let clicking = false;

		this.renderRect({
			normalize: true,
			anchor: [0.5, 0.5],
			size: [this.player.sceneWidth, this.player.sceneHeight],
			pos: [this.player.sceneWidth / 2, this.player.sceneHeight / 2],
			fillColor: 'rgba(0,0,0,0.5)',
		});

		this.renderSprite({
			size: [283, 442],
			anchor: [0.5, 0.5],
			pos: [568, 528],
			texture: 'help-01',
		});

		this.renderSprite({
			size: [540, 307],
			anchor: [0.5, 0.5],
			pos: [380, 1180],
			texture: 'help-02',
		});

		const help = this.renderSprite({
			size: [300, 98],
			anchor: [0.5, 0.5],
			pos: [375, 900],
			texture: 'help-btn',
		}).addEventListener('click', async () => {
			await help.transition(0.1, 'ease-in').attr({
				scale: [0.8, 0.8],
			});
			await help.transition(0.1, 'ease-in').attr({
				scale: [1, 1],
			});

			if (clicking) {
				return;
			}

			clicking = true;

			try {
				this.onHelpBtnClick();
			} finally {
				clicking = false;
			}
		});
	}
}
