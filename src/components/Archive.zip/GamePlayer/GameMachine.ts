import { sleep } from '../../interface/index';
import { Attrs, Group, Layer, Sprite } from 'spritejs';
import { noop } from '../../utils/misc-utils';
import { GamePlayer } from './GamePlayer';
import { GameScript } from './GameScript';

const TRACK_SPEED = 4000;
const FA_WIDTH = 174;
const FA_HEIGHT = 214;
const FA_GAP = 46;

interface Fa {
	node: Group;
	animate: () => void;
}

interface Claw {
	node: Group;
	draw: (options?: { prizeId?: number }) => Promise<void>;
	reset: () => void;
}

export class GameMachine extends GameScript {
	readonly layer: Layer;
	private animationList: Array<() => void> = [];
	public claw: Claw | undefined;

	constructor(private player: GamePlayer, options: { zIndex: number; layer: Layer }) {
		super();
		this._zIndex = options.zIndex;
		this.layer = options.layer;
		this.claw = this.createClaw();
	}

	setup() {
		this.animationList.push(this.setupTrack(), this.setupFaTrack());
	}

	private setupTrack(): () => void {
		const center = this.player.sceneWidth / 2;
		const width = this.player.sceneWidth;

		const tracks = Array.from<[number, boolean, () => Partial<Attrs>]>([
			[
				900,
				true,
				() => ({
					size: [width * 2, 69],
					texture: 'track-back',
					textureRect: [0, 0, 750, 69],
					textureRepeat: true,
					zIndex: 0,
				}),
			],
			[
				1020,
				false,
				() => ({
					size: [width * 2, 88],
					texture: 'track-front',
					textureRect: [0, 0, 750, 88],
					textureRepeat: true,
					zIndex: 100,
				}),
			],
		]).map<[Sprite, boolean]>(([posY, reverse, attrs]) => {
			return [
				this.renderSprite({
					...attrs(),
					anchor: [0, 0.5],
					pos: [center - width / 2, posY],
				}),
				reverse,
			];
		});

		return () => {
			for (const [track, reverse] of tracks) {
				track.animate([{ x: reverse ? 0 : -width }, { x: reverse ? -width : 0 }], {
					duration: TRACK_SPEED,
					iterations: Infinity,
				});
			}
		};
	}

	private setupFaTrack() {
		let keys = [...this.player.prizeList];

		if (keys.length < 4) {
			keys = Array(4)
				.fill(0)
				.map(() => keys)
				.reduce((acc, val) => acc.concat(val), [])
				.slice(0, 4);
		}

		if (keys.length <= 0) {
			return noop;
		}

		const center = keys.length % 2 !== 0 ? 375 : 375 + (FA_WIDTH + FA_GAP) / 2;
		const width = keys.length * (FA_WIDTH + FA_GAP);
		const faList: Fa[] = [];

		const createFaList = (group: Group, attrs: () => Partial<Attrs>) =>
			keys.map<Fa>((prize, idx) => {
				const offset = -(width / 2) + (FA_WIDTH + FA_GAP) * idx;

				const fa = this.createFa({
					attrs: () => ({
						...attrs(),
						pos: [offset, 0],
					}),
					texture: prize.prizeImg,
				});

				group.append(fa.node);

				return fa;
			});

		const trackList = Array.from<[number, boolean, () => Partial<Attrs>, () => Partial<Attrs>]>([
			[824, true, () => ({ scale: [0.7, 0.7] }), () => ({ zIndex: 10 })],
			[914, false, () => ({}), () => ({ zIndex: 110 })],
		]).map<[Group, Group, boolean]>(([posY, reverse, attrs, groupAttrs]) => {
			const track = this.createGroup({
				anchor: [0.5, 0.5],
				size: [width, FA_HEIGHT],
				...groupAttrs(),
				pos: [center, posY],
			});

			faList.push(...createFaList(track, attrs));

			const trackShadow = this.createGroup({
				anchor: [0.5, 0.5],
				size: [width, FA_HEIGHT],
				...groupAttrs(),
				pos: [center + (reverse ? width : -width), posY],
			});

			faList.push(...createFaList(trackShadow, attrs));

			this.layer.append(track);
			this.layer.append(trackShadow);

			return [track, trackShadow, reverse];
		});

		// mask
		this.renderSprite({
			anchor: [0.5, 0.5],
			size: [this.player.sceneWidth, 180],
			pos: [this.player.sceneWidth / 2, 826],
			texture: 'fa-mask',
			textureRect: [0, 0, 750, 180],
			zIndex: 30,
		});

		// hook
		this.claw = this.createClaw();
		this.layer.append(this.claw.node);

		return () => {
			for (const fa of faList) {
				fa.animate();
			}

			const duration = width / (this.player.sceneWidth / TRACK_SPEED);

			for (const [track, trackShadow, reverse] of trackList) {
				track.animate([{ x: center }, { x: reverse ? center - width : center + width }], {
					duration,
					iterations: Infinity,
				});

				trackShadow.animate([{ x: reverse ? center + width : center - width }, { x: center }], {
					duration,
					iterations: Infinity,
				});
			}
		};
	}

	protected createFa(options: { attrs: () => Partial<Attrs>; texture?: string }): Fa {
		const background = this.createSprite({
			anchor: [0.5, 0.5],
			size: [174, 214],
			pos: [0, 0],
			textureRect: [0, 0, 174, 214],
			texture: 'fa-bg',
		});

		const brand =
			options.texture &&
			this.createSprite({
				anchor: [0.5, 0.5],
				pos: [0, 30],
				textureRect: [0, 0, 174, 118],
				texture: options.texture,
			});

		const earLeft = this.createSprite({
			anchor: [0.5, 0.5],
			size: [88, 88],
			pos: [-44, -56],
			texture: 'fa-ear-left',
		});

		const earRight = this.createSprite({
			anchor: [0.5, 0.5],
			size: [88, 88],
			pos: [44, -56],
			texture: 'fa-ear-right',
		});

		const handLeft = this.createSprite({
			anchor: [0.5, 0.5],
			size: [31, 28],
			pos: [-80, 40],
			texture: 'fa-hand-left',
		});

		const handRight = this.createSprite({
			anchor: [0.5, 0.5],
			size: [31, 28],
			pos: [80, 40],
			texture: 'fa-hand-right',
		});

		const node = this.createGroup({
			anchor: [0.5, 0.5],
			size: [174, 214],
			...options.attrs(),
		});

		node.append(...[...[earLeft, earRight, background], ...(brand ? [brand] : []), ...[handLeft, handRight]]);

		return {
			node,
			animate: () => {
				for (const ear of [earLeft, earRight]) {
					ear.animate([{ scale: 1.1 }, { scale: 1 }, { scale: 1.1 }], {
						duration: 750,
						iterations: Infinity,
					});
				}

				for (const hand of [handLeft, handRight]) {
					hand.animate([{ y: 44 }, { y: 36 }, { y: 44 }], {
						duration: 750,
						iterations: Infinity,
					});
				}
			},
		};
	}

	protected createClaw(): Claw {
		const nodeBasePos: [number, number] = [375, 100];

		const node = this.createGroup({
			anchor: [0.5, 0.5],
			size: [194, 800],
			pos: nodeBasePos,
			zIndex: 40,
		});

		node.appendChild(
			this.createSprite({
				anchor: [0.5, 0.5],
				size: [22, 750],
				texture: 'hook-body',
				textureRect: [0, 0, 22, 750],
				pos: [0, -200],
				zIndex: 44,
			}),
		);

		const claw: Sprite = node.appendChild(
			this.createSprite({
				anchor: [0.5, 0.5],
				size: [194, 194],
				texture: 'claw-01',
				pos: [0, 230],
				zIndex: 44,
			}),
		);

		let fa: Fa | undefined;

		return {
			node,
			draw: async (options?: { prizeId?: number }) => {
				this.player.playSound('claw-draw');

				await node.transition(1).attr({
					y: (y: number) => y + 450,
				} as any);

				claw.attr({
					texture: 'claw-02',
				});

				await sleep(100);

				claw.attr({
					texture: 'claw-03',
				});

				await sleep(300);

				const prize =
					this.player.prizeList[this.player.prizeList.findIndex((prize) => prize.id === options?.prizeId)];

				if (prize) {
					fa = this.createFa({
						attrs: () => ({
							pos: [0, 362],
							zIndex: 42,
						}),
						texture: prize.prizeImg,
					});

					node.append(fa.node);
					fa.animate();
				}

				await sleep(400);

				await node.transition(1).attr({
					y: (y: number) => y - 350,
				} as any);
			},
			reset: () => {
				if (fa) {
					this.remove(fa.node);
				}

				node.attr({
					pos: nodeBasePos,
				});

				claw.attr({
					texture: 'claw-01',
				});
			},
		};
	}

	start() {
		for (const animation of this.animationList) {
			animation();
		}
	}
}
