import { Animation, Group, Label, Layer, Sprite } from 'spritejs';
import { clamp, padZero } from '../../utils/misc-utils';
import { GamePlayer } from './GamePlayer';
import { GameScript } from './GameScript';

export class GameShell extends GameScript {
	protected layer: Layer;
	protected fan: [Sprite, Sprite] | undefined;
	protected fanAnimation: [Animation, Animation] | undefined;
	private pointsNode: Label | undefined;
	private remainingNode: Sprite | undefined;
	private remaining = 0;

	constructor(private player: GamePlayer, options: { zIndex: number; layer: Layer }) {
		super();
		this._zIndex = options.zIndex;
		this.layer = options.layer;
	}

	async handleClick(node: Sprite, cb?: () => void) {
		this.player.playSound('button-press');

		await node.transition(0.1, 'ease-in').attr({
			scale: [0.8, 0.8],
		});
		await node.transition(0.1, 'ease-in').attr({
			scale: [1, 1],
		});
		cb && cb();
	}

	setup() {
		// 背景
		this.renderSprite({
			anchor: [0, 0],
			size: [this.player.sceneWidth, 1507],
			pos: [0, 0],
			texture: 'game-shell',
		});

		// 霓虹灯
		const neon = Array.from<[[number, number], number, string]>([
			[[-14, 210], 1, 'yellow'],
			[[-14, 210], 0, 'pink'],
			[[702, 210], 1, 'yellow'],
			[[702, 210], 0, 'pink'],
		]).map<Group>(([pos, opacity, type]) => {
			const group = this.createGroup({
				size: [63, 879],
				anchor: [0, 0.5],
				pos,
				opacity,
			});

			for (let i = 0; i < 12; i++) {
				group.append(
					this.createSprite({
						anchor: [0, 0],
						size: [63, 63],
						pos: [0, i * 68],
						texture: `neon-${type}`,
					}),
				);

				type = type === 'pink' ? 'yellow' : 'pink';
			}

			return this.layer.appendChild(group);
		});

		// 风扇
		this.fan = [
			this.renderSprite({
				anchor: [0.5, 0.5],
				size: [64, 64],
				pos: [162, 126],
				texture: 'fan',
				textureRect: [0, 0, 64, 64],
			}),
			this.renderSprite({
				anchor: [0.5, 0.5],
				size: [64, 64],
				pos: [587, 126],
				texture: 'fan',
				textureRect: [0, 0, 64, 64],
			}),
		];

		// LOGO
		let logoTexture = 'logo';
		const logo = this.renderSprite({
			anchor: [0.5, 0],
			size: [390, 162],
			pos: [375, 20],
			texture: logoTexture,
		});

		this.player.ticker.interval(() => {
			for (const n of neon) {
				n.attr({
					opacity: n.opacity > 0 ? 0 : 1,
				});
			}

			logoTexture = logoTexture === 'logo' ? 'logo-active' : 'logo';
			logo.attr({ texture: logoTexture });
		}, 500);

		// 活动规则
		const btnRule = this.renderSprite({
			anchor: [0.5, 0.5],
			size: [66, 124],
			pos: [666, 390],
			scale: [1, 1],
			texture: 'btn-rule',
		}).addEventListener('click', () => {
			this.handleClick(btnRule, this.player.options.onBtnRuleClick);
		});

		// 我的奖品
		const btnPrize = this.renderSprite({
			anchor: [0.5, 0.5],
			size: [66, 125],
			pos: [666, 540],
			scale: [1, 1],
			texture: 'btn-prize',
		}).addEventListener('click', () => {
			this.handleClick(btnPrize, this.player.options.onBtnPrizeClick);
		});

		// 获取更多次数
		const btnAcquireMore = this.renderSprite({
			anchor: [0.5, 0.5],
			size: [273, 119],
			pos: [240, 1246],
			scale: [1, 1],
			texture: 'btn-acquire-more',
		}).addEventListener('click', () => {
			this.handleClick(btnAcquireMore, this.player.options.onBtnMoreClick);
		});

		// OK
		const btnOk = this.renderSprite({
			anchor: [0.5, 0.5],
			size: [218, 187],
			pos: [530, 1230],
			scale: [1, 1],
			texture: 'btn-ok',
		}).addEventListener('click', () => {
			this.handleClick(btnOk, this.player.options.onBtnClawClick);
		});

		this.remainingNode = this.renderSprite({
			anchor: [0.5, 0.5],
			size: [28, 28],
			pos: [300, 1162],
			texture: `num-${padZero(this.remaining, 2)}`,
		});

		const points = new Label('当前积分:');

		points.attr({
			pos: [20, 32],
			fillColor: '#fffa94',
			font: 'bold 26px Microsoft Yahei',
			zIndex: this._zIndex,
		});

		this.layer.appendChild(points);
		this.pointsNode = points;
	}

	setRemaining(remaining: number) {
		this.remaining = clamp(remaining, 0, 10);

		this.remainingNode?.attr({
			texture: `num-${padZero(this.remaining, 2)}`,
		});
	}

	setPoints(points: number) {
		if (this.pointsNode) {
			this.pointsNode.text = `当前积分:${points}`;
		}
	}

	start() {
		if (this.fan) {
			const [fanLeft, fanRight] = this.fan;

			this.fanAnimation = [
				fanLeft.animate([{ rotate: 0 }, { rotate: 360 }], {
					duration: 1000,
					iterations: Infinity,
				}),
				fanRight.animate([{ rotate: 720 }, { rotate: 360 }], {
					duration: 1000,
					iterations: Infinity,
				}),
			];
		}
	}
}
