import { Layer } from 'spritejs';
import { GamePlayer } from './GamePlayer';
import { GameScript } from './GameScript';

export class GameBackground extends GameScript {
	protected layer: Layer;

	constructor(private player: GamePlayer, options: { zIndex: number; layer: Layer }) {
		super();
		this._zIndex = options.zIndex;
		this.layer = options.layer;
	}

	setup() {
		// 背景 1px 重复
		this.renderSprite({
			anchor: [0, 0],
			size: [this.player.sceneWidth, this.player.sceneHeight],
			pos: [0, 0],
			texture: 'game-bg',
			textureRepeat: true,
		});

		// 背景 RT
		this.renderSprite({
			anchor: [0, 0],
			size: [this.player.sceneWidth, 964],
			pos: [0, 140],
			texture: 'game-bg-rt',
		});
	}

	start() {
		// none
	}
}
