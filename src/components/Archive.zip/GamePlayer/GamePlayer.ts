import 'isomorphic-fetch';
import { Dictionary } from '../../interface/index';
import { Howl } from 'howler';
import Cookies from 'js-cookie';
import { Scene } from 'spritejs';
import { CM } from '../../core/interfaces';
import { Ticker } from '../../utils/tick-utils';
import audioBackground from './assets/sounds/background.mp3';
import audioButtonPress from './assets/sounds/button-press.mp3';
import audioCardFusion from './assets/sounds/card-fusion.mp3';
import audioClawDraw from './assets/sounds/claw-draw.mp3';
import jsonGameTexture from './assets/textures/game-texture.json';
import imgGameTexture from './assets/textures/game-base64/game-texture.txt';
import imgGameShell from './assets/textures/game-base64/game-shell.txt';
import imgGameBg from './assets/textures/game-base64/game-bg.txt';
import imgGameBgRt from './assets/textures/game-base64/game-bg-rt.txt';
import imgFaMask from './assets/textures/game-base64/fa-mask.txt';
import imgTrackBack from './assets/textures/game-base64/track-back.txt';
import imgTrackFront from './assets/textures/game-base64/track-front.txt';
import { GameBackground } from './GameBackground';
import { GameHelp } from './GameHelp';
import { GameMachine } from './GameMachine';
import { GameShell } from './GameShell';

export interface GamePlayerOptions {
	onBtnRuleClick?: () => void;
	onBtnPrizeClick?: () => void;
	onBtnMoreClick?: () => void;
	onBtnClawClick?: () => void;
}

export class GamePlayer {
	readonly scene: Scene;
	readonly canvasContainer: HTMLDivElement;
	readonly sceneWidth = 750;
	readonly sceneHeight: number;
	readonly ticker = new Ticker();
	readonly prizeList: Array<Required<CM.Prize>> = [];
	readonly audio: Dictionary<Howl> = {};
	background: GameBackground | undefined;
	shell: GameShell | undefined;
	machine: GameMachine | undefined;
	help: GameHelp | undefined;

	constructor(protected stage: HTMLDivElement, readonly options: GamePlayerOptions = {}) {
		const rect = this.stage.getBoundingClientRect();

		this.canvasContainer = document.createElement('div');
		this.canvasContainer.style.width = '100%';
		this.canvasContainer.style.height = '100%';
		this.canvasContainer.style.overflow = 'hidden';
		this.canvasContainer.style.position = 'relative';

		stage.appendChild(this.canvasContainer);

		this.sceneHeight = Math.max(this.sceneWidth * (rect.height / rect.width), 1334);

		this.scene = new Scene({
			container: this.canvasContainer,
			width: this.sceneWidth,
			height: this.sceneHeight,
		});
	}

	async load() {
		for (const [name, image] of Array.from<[string, any]>([
			['game-shell', imgGameShell],
			['game-bg', imgGameBg],
			['game-bg-rt', imgGameBgRt],
			['fa-mask', imgFaMask],
			['track-back', imgTrackBack],
			['track-front', imgTrackFront],
		])) {
			const data = await fetch(image).then((resp) => resp.text());

			await this.scene.preload({
				id: name,
				src: data,
			});
		}

		for (const [json, image] of Array.from<[any, any]>([[jsonGameTexture, imgGameTexture]])) {
			const data = await fetch(image).then((resp) => resp.text());
			await this.scene.preload([data, json]);
		}

		for (const [name, audio] of Array.from<[string, any]>([
			['background', audioBackground],
			['button-press', audioButtonPress],
			['card-fusion', audioCardFusion],
			['claw-draw', audioClawDraw],
		])) {
			this.audio[name] = await this.loadAudio(name, audio);
		}
	}

	async init(options: { prizeList?: CM.Prize[] } = {}) {
		const loaded: Dictionary<string> = {};

		for (const prize of options.prizeList || []) {
			if (prize.id != null && prize.prizeImg != null) {
				let texture: string | undefined = loaded[prize.prizeImg];

				if (!texture) {
					const src = 'data:image/png;base64,' + prize.prizeImg;
					texture = loaded[prize.prizeImg] = `prize-image-${prize.id}`;

					await this.scene.preload({
						id: texture,
						src: src,
					});
				}

				this.prizeList.push({
					id: prize.id,
					prizeImg: texture,
				});
			}
		}
	}

	playSound(name: string, audio: (howl: Howl) => Howl = (h) => h) {
		const howl: Howl | undefined = this.audio[name];

		if (howl) {
			audio(howl).play();
		}
	}

	start() {
		const layer = this.scene.layer();

		this.background = new GameBackground(this, {
			zIndex: 0,
			layer,
		});

		this.machine = new GameMachine(this, {
			zIndex: 1000,
			layer,
		});

		this.shell = new GameShell(this, {
			zIndex: 2000,
			layer,
		});

		this.help = new GameHelp(this, {
			zIndex: 3000,
			layer,
		});

		this.background.setup();
		this.shell.setup();
		this.machine.setup();
		this.help.setup();

		layer.tick(() => {
			this.ticker.tick();
		});

		this.audio['background'].loop(true).play();

		let showHelp = false;

		if (!Cookies.get('FNG_CLAW_MACHINE_HELP')) {
			showHelp = true;
			Cookies.set('FNG_CLAW_MACHINE_HELP', '1', {
				expires: 72, // 72 天
			});
		}

		if (!showHelp) {
			this.background.start();
			this.shell.start();
			this.machine.start();
		} else {
			this.help.start();

			this.help.onHelpBtnClick = () => {
				this.help?.destroy();
				this.background?.start();
				this.shell?.start();
				this.machine?.start();
			};
		}
	}

	destroy() {
		this.ticker.pause();
		this.scene.remove();
		this.canvasContainer.remove();
	}

	private async loadAudio(name: string, audio: any): Promise<Howl> {
		return new Promise<Howl>((resolve, reject) => {
			const howl = new Howl({
				src: audio,
				preload: false,
				onload: () => {
					resolve(howl);
				},
				onloaderror: (soundId, err: any) => {
					reject(new Error(`Sound ${name} load error: ${err?.message || err}`));
				},
			});

			howl.load();
		});
	}
}
