import { Button, Dialog } from 'fnx-ui';
import { DialogProps } from 'fnx-ui/lib/dialog';
import PopupHelper from 'fnx-ui/lib/popup/utils/popup-helper';
import React, { useEffect, useState } from 'react';
import iconClose from '../../assets/icon-close.png';
import { classnames, createBEM } from '../../utils/class-utils';
import { noop } from '../../utils/misc-utils';
import { createFC } from '../../utils/react-utils';
import './index.less';

type CProps = DialogProps;

export interface GameDialogInstance {
	update: (props: CProps) => void;
	clear: () => void;
}

export interface GameDialogExportExtra {
	show: (props: CProps) => GameDialogInstance;
}

const bem = createBEM('game-dialog');

const helper = new PopupHelper();

const CGameDialog = createFC<CProps>(
	'GameDialog',
	({
		className,
		bodyProps,
		confirmButton,
		confirmLoading,
		confirmText,
		confirmButtonProps = {},
		cancelButton,
		onCancel,
		onConfirm,
		message,
		title,
		children,
		...props
	}) => {
		return (
			<Dialog
				{...props}
				className={classnames(bem(), className)}
				footer={false}
				bodyProps={{ ...bodyProps, className: classnames(bem('body'), bodyProps?.className) }}
				title={
					<div className={bem('title')}>
						{title}
						{cancelButton !== false && (
							<div className={bem('close')}>
								{cancelButton || (
									<img
										onClick={() => {
											onCancel && onCancel();
										}}
										className={bem('close-icon')}
										src={iconClose}
									/>
								)}
							</div>
						)}
					</div>
				}
			>
				{message && <div className={bem('message')}>{message}</div>}
				{children}
				{confirmButton !== false && (
					<div className={bem('footer')}>
						{confirmButton || (
							<Button
								shape="round"
								color="linear-gradient(90deg, #FF4ACF 0%, #9D7AF6 100%)"
								loading={confirmLoading}
								{...confirmButtonProps}
								className={classnames(bem('confirm'), confirmButtonProps.className)}
								onClick={(...args) => {
									onConfirm && onConfirm();
									confirmButtonProps.onClick && confirmButtonProps.onClick(...args);
								}}
							>
								{confirmText}
							</Button>
						)}
					</div>
				)}
			</Dialog>
		);
	},
);

const show = (baseProps: CProps, options: { container?: HTMLElement } = {}): GameDialogInstance => {
	return helper.create<CProps>(({ onUpdate, remove }) => {
		const GameDialogStatic = createFC<CProps>('GameDialogStatic', () => {
			const [{ onAfterHide, ...props }, setProps] = useState(baseProps);

			useEffect(() => {
				const listener = (next: CProps) => {
					setProps((prev) => ({ ...prev, ...next }));
				};

				return onUpdate(listener);
			}, []);

			const handleAction = (fn: (() => any) | undefined) => {
				const res: any = (fn || noop)();

				if (res !== false) {
					setProps((prev) => ({
						...prev,
						visible: false,
					}));
				}
			};

			return (
				<CGameDialog
					visible={true}
					{...props}
					mountTo={false}
					onAfterHide={() => {
						remove();
						onAfterHide && onAfterHide();
					}}
					onConfirm={() => handleAction(props.onConfirm)}
					onCancel={() => handleAction(props.onCancel)}
				/>
			);
		});

		return GameDialogStatic;
	}, options.container);
};

const GameDialog: typeof CGameDialog & GameDialogExportExtra = CGameDialog as any;
GameDialog.show = show;

export default GameDialog;
