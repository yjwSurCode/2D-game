import { Button, Tabs, Toast } from 'fnx-ui';
import { PopupProps } from 'fnx-ui/lib/popup';
import React, { useEffect, useMemo, useState } from 'react';
import imgAvatarRound from '../../assets/avatar-round.png';
import emptyImg from '../../assets/empty.png';
import { GAME_CARD_LIST, GAME_CMS_AID, PROJECT_PATHS, PROJECT_ROUTE_BASE } from '../../core/config';
import { RunningEnv } from '../../core/constants';
import { CM, GameCard } from '../../core/interfaces';
import { useAsyncFn } from '../../hooks/use-advanced';
import { useErrorHandler } from '../../hooks/use-error-handler';
import { useLockFn } from '../../hooks/use-side-effect';
import backendService from '../../services/backend-service';
import { classnames, createBEM } from '../../utils/class-utils';
import { appendQuery } from '../../utils/history-utils';
import { NativeWechatShareInfo, NATIVE_BRIDGE } from '../../utils/native-utils';
import { PLATFORM_BRIDGE } from '../../utils/platform-utils';
import { createFC } from '../../utils/react-utils';
import GamePopup from '../GamePopup';
import './index.less';

const bem = createBEM('prize-popup');

interface CProps extends PopupProps {
	couponList?: CM.ReceivedCoupon[];
	cardList?: CM.ReceivedCard[];
	pointsList?: CM.ReceivedPoint[];
	sendList?: CM.SendRecord[];
	userAct?: CM.UserActInfo;
	storeCode?: string;
	actId?: number;
	userNickname?: string;
	userAvatar?: string;
	onShowShareTip?: () => void;
	onShowCardFusion?: () => void;
}

interface NavItem {
	value: string;
	label: string;
}

const NAV_LIST: NavItem[] = [
	{
		label: '中奖记录',
		value: 'prize',
	},
	{
		label: '赠送记录',
		value: 'send',
	},
];

interface Card extends GameCard {
	totalCount: number;
	receivedCount: number;
}

const formatCardList = (cardList: CM.ReceivedCard[]): Card[] => {
	return GAME_CARD_LIST.map<Card>((card) => {
		let totalCount = 0;
		let receivedCount = 0;

		for (const c of cardList) {
			if (c.cardType === card.type) {
				totalCount++;
				receivedCount += c.cardFrom === 1 ? 1 : 0;
			}
		}

		return {
			...card,
			totalCount,
			receivedCount,
		};
	});
};

const PrizePopup = createFC<CProps>(
	'PrizePopup',
	({
		className,
		userAct,
		storeCode,
		userNickname,
		userAvatar,
		actId,
		onShowShareTip,
		onShowCardFusion,
		style,
		couponList,
		cardList: _cardList,
		pointsList,
		sendList: _sendList,
		...props
	}) => {
		const [handleError] = useErrorHandler();
		const [nav, setNav] = useState<string>('prize');
		const [selectedCard, setSelectedCard] = useState<Card>();
		const [cardList, setCardList] = useState<Card[]>(() => formatCardList(_cardList || []));

		const totalPoints = useMemo(() => {
			return (pointsList || []).map((p) => p.points || 0, []).reduce<number>((a, b) => a + b, 0);
		}, [pointsList]);

		const sendList = useMemo(() => {
			return (_sendList || []).map<CM.SendRecord & Partial<GameCard>>((send) => {
				const card = GAME_CARD_LIST[GAME_CARD_LIST.findIndex((card) => card.type === send.cardType)];

				if (!card) {
					return send;
				}

				return { ...send, ...card };
			});
		}, [_sendList]);

		const handleNavChange = (nextNav: string) => {
			if (nav === nextNav) {
				return;
			}

			setNav(nextNav);
		};

		const handleSelectCard = (card: Card) => {
			setSelectedCard((prev) => (prev?.type !== card.type ? card : undefined));
		};

		const [, { run: _sendCard }] = useAsyncFn(
			async (options: {
				storeCode: string;
				guid: string;
				guidMd5: string;
				actId: number;
				card: GameCard;
				userNickname?: string;
				userAvatar?: string;
			}): Promise<[RunningEnv, string]> => {
				const { storeCode, guid, guidMd5, card, userNickname, userAvatar } = options;

				const token = await backendService.getShareToken({
					storeCode,
					memGuid: guid,
					memMd5: guidMd5,
					memName: userNickname,
					memAvatar: userAvatar,
					tokenId: card.type,
					tokenType: 2,
				});

				const env = await PLATFORM_BRIDGE.getRunningEnv();

				return [env, token];
			},
			{
				onSuccess: (res, [{ storeCode, card }]) => {
					const [runningEnv, token] = res;

					const shareTitle = `送你一张${card.name}，快来大润发app参与抓娃娃游戏，海量大奖等你来`;

					// 设置分享
					const shareUrl = `${PROJECT_PATHS.project}${PROJECT_ROUTE_BASE}/inflow/${token}`;

					if (runningEnv === RunningEnv.WeApp) {
						PLATFORM_BRIDGE.postMessage({
							title: shareTitle,
							src: appendQuery('pages/www/cms', {
								f: shareUrl,
								aid: GAME_CMS_AID,
								sid: storeCode,
							}),
						});

						onShowShareTip?.();
					} else if (runningEnv === RunningEnv.Ios || runningEnv === RunningEnv.Android) {
						const shareInfo: NativeWechatShareInfo = {
							shareTitle,
							shareContent: '',
							shareContentUrl: 'https://yxsale.feiniu.com/act/htm/about-youxian.html',
							shareImageUrl:
								'https://img17.fn-mart.com/pic/fccb134a3cb9210b476f/K26z225zF2tMBlUdl2/s9maoaWy3GB9oR/CtCLmGLWRuyAECTnAAGSYSL-3XE721.jpg',
							smallTalkId: 'gh_5a75412a617c',
							smallTalkPath: appendQuery('/pages/www/cms', {
								f: shareUrl,
								aid: GAME_CMS_AID,
								sid: storeCode,
							}),
						};

						NATIVE_BRIDGE.wechatShare({
							...shareInfo,
							shareTarget: 'frineds',
						});

						props.onClose?.();
					} else {
						Toast.show('该渠道暂不支持分享');
						props.onClose?.();
					}
				},
				onError: (err) => handleError(err),
			},
		);

		const sendCard = useLockFn(async () => {
			if (!selectedCard) {
				Toast.show('请选择一张卡牌赠送');
				return;
			}

			if (selectedCard.type === 'fa') {
				Toast.show(`${selectedCard.name}不可赠送`);
				return;
			}

			if (selectedCard.totalCount <= 1) {
				Toast.show(`您只有1张${selectedCard.name}，暂不可赠送该卡`);
				return;
			}

			if (selectedCard.totalCount === selectedCard.receivedCount) {
				Toast.show('好友赠送的卡牌不可转赠');
				return;
			}

			const guid = userAct?.memGuid;
			const guidMd5 = userAct?.memMd5;

			if (storeCode == null || guid == null || guidMd5 == null || actId == null) {
				Toast.show('赠送失败');
				return;
			}

			return _sendCard({
				storeCode,
				guid,
				guidMd5,
				actId,
				card: selectedCard,
				userNickname,
				userAvatar,
			});
		});

		const [, { run: _fusionCards }] = useAsyncFn(
			async (options: { storeCode: string; guid: string; guidMd5: string; actId: number }): Promise<void> => {
				await backendService.cardsCombine({
					storeCode: options.storeCode,
					memGuid: options.guid,
					memMd5: options.guidMd5,
					actId: options.actId,
				});
			},
			{
				onSuccess: () => {
					setSelectedCard(undefined);

					setCardList((prev) => {
						if (!prev) {
							return prev;
						}

						let wanUsed = 0;

						let next = prev.map<Card>((card) => {
							if (card.type === 'fa') {
								return {
									...card,
									totalCount: card.totalCount + 1,
								};
							}

							if (card.type === 'wan') {
								return card;
							}

							if (card.totalCount <= 0) {
								wanUsed--;
								return card;
							} else {
								return {
									...card,
									totalCount: card.totalCount - 1,
									receivedCount: Math.max(card.receivedCount - 1, 0),
								};
							}
						});

						if (wanUsed > 0) {
							next = next.map((card) => {
								return card.type !== 'wan'
									? card
									: {
											...card,
											totalCount: card.totalCount - wanUsed,
											receivedCount: Math.max(card.receivedCount - wanUsed, 0),
									  };
							});
						}

						return next;
					});

					onShowCardFusion?.();
				},
				onError: (err) => handleError(err),
			},
		);

		const fusionCards = useLockFn(async () => {
			const size = cardList
				.map<number>((card) => (card.type === 'fa' ? 0 : card.totalCount))
				.reduce<number>((a, b) => a + b, 0);

			if (size < 12) {
				Toast.show('你还没有集齐12张全家福卡牌');
				return;
			}

			const guid = userAct?.memGuid;
			const guidMd5 = userAct?.memMd5;

			if (storeCode == null || guid == null || guidMd5 == null || actId == null) {
				Toast.show('合成失败');
				return;
			}

			return _fusionCards({
				storeCode,
				guid,
				guidMd5,
				actId,
			});
		});

		useEffect(() => {
			// 显示时清空选择
			if (props.visible) {
				setSelectedCard(undefined);
			}
		}, [props.visible]);

		useEffect(() => {
			setCardList(formatCardList(_cardList || []));
		}, [_cardList]);

		const renderEmpty = (desc: string) => {
			return (
				<div className={bem('empty')}>
					<div className={bem('empty-inner')}>
						<img src={emptyImg} />
						<p>{desc}</p>
					</div>
				</div>
			);
		};

		const renderCouponList = () => {
			if (!couponList || couponList.length <= 0) {
				return <div className={bem('coupon-list')}>{renderEmpty('您还没有获得任何的优惠券')}</div>;
			}

			return (
				<div className={bem('coupon-list')}>
					<div className={bem('coupon-list-desc')}>请至【我的】-【优惠券】中查看和使用</div>
					<ul className={bem('coupon-list-inner')}>
						{couponList.map((coupon, idx) => {
							return (
								<li className={bem('coupon')} key={idx}>
									<div className={bem('coupon-label')}>优惠券</div>
									<div className={bem('coupon-sep')}>
										<i />
									</div>
									<div className={bem('coupon-body')}>
										<img className={bem('coupon-img')} src={coupon.prizeImg || imgAvatarRound} />
										<div className={bem('coupon-content')}>
											<p className={bem('coupon-name')}>{coupon.couponName}</p>
											<p className={bem('coupon-desc')}>{coupon.couponInfo}</p>
										</div>
									</div>
								</li>
							);
						})}
					</ul>
				</div>
			);
		};

		const renderCardList = () => {
			return (
				<div className={bem('card-list')}>
					<div className={bem('card-list-desc')}>集齐12张全家福卡牌可合成为发发卡</div>

					<ul className={bem('card-list-inner')}>
						{cardList.map((card) => {
							const disabled = card.totalCount <= 0;

							return (
								<li
									key={card.type}
									className={bem('card')}
									onClick={() => {
										if (!disabled) {
											handleSelectCard(card);
										}
									}}
								>
									<div
										className={bem('card-pic', {
											disabled,
											selected: selectedCard?.type === card.type,
										})}
									>
										<img className={bem('card-pic-img')} src={card.imageURL} />
										{!disabled && card.receivedCount > 0 && (
											<div className={bem('card-pic-received-tip')}>
												好友赠送x{card.receivedCount}
											</div>
										)}
										<i></i>
									</div>
									<div className={bem('card-label')}>
										{card.name}
										{card.totalCount > 1 ? `x${card.totalCount}` : ''}
									</div>
								</li>
							);
						})}
					</ul>

					<div className={bem('card-list-footer')}>
						<Button
							shape="round"
							color="#6B58F7"
							className={bem('card-list-footer-cancel')}
							onClick={() => {
								sendCard();
							}}
						>
							赠送1张给好友
						</Button>
						<div className={bem('card-list-footer-sep')}></div>
						<Button
							shape="round"
							className={bem('card-list-footer-combine')}
							color="linear-gradient(90deg, #FF4ACF 0%, #9D7AF6 100%)"
							onClick={() => {
								fusionCards();
							}}
						>
							去合成
						</Button>
					</div>
				</div>
			);
		};

		const renderPointList = () => {
			if (!pointsList || pointsList.length <= 0) {
				return <div className={bem('coupon-list')}>{renderEmpty('您还没有获得任何的积分')}</div>;
			}

			return (
				<div className={bem('point-list')}>
					<div className={bem('point-list-header')}>
						<p>您获得的积分共</p>
						<p className={bem('point-list-value')}>
							<span>{totalPoints}</span>
						</p>
					</div>

					<ul className={bem('point-list-inner')}>
						{pointsList.map((point, idx) => {
							return (
								<li key={idx} className={bem('point')}>
									<div className={bem('point-extra')}>+{point.points}</div>
									<div className={bem('point-content')}>
										<p className={bem('point-title')}>抽中的积分</p>
										<p className={bem('point-date')}>{point.createTime}</p>
									</div>
								</li>
							);
						})}
					</ul>
				</div>
			);
		};

		const renderSendList = () => {
			if (!sendList || sendList.length <= 0) {
				return renderEmpty('您还没有赠送记录');
			}

			return (
				<div className={bem('send-list-inner')}>
					{sendList.map((send, idx) => {
						return (
							<div key={idx} className={bem('send')}>
								<div className={bem('send-content')}>
									<p className={bem('send-line')}>
										<span className={bem('send-label')}>卡牌名称：</span>
										<span className={bem('send-value')}>{send.name}</span>
									</p>
									<p className={bem('send-line')}>
										<span className={bem('send-label')}>赠送时间：</span>
										<span className={bem('send-value')}>{send.receiveTime}</span>
									</p>
									<p className={bem('send-line')}>
										<span className={bem('send-label')}>赠送对象：</span>
										<img className={bem('send-avatar')} src={send.memAvatar || imgAvatarRound} />
										<span className={bem('send-name')}>{send.memName}</span>
									</p>
								</div>

								<img className={bem('send-card')} src={send.imageURL} />
							</div>
						);
					})}
				</div>
			);
		};

		return (
			<GamePopup
				{...props}
				title="我的奖品"
				style={{ height: '90%', ...style }}
				className={classnames(bem(), className)}
			>
				<div className={bem('body')}>
					<div className={bem('nav')}>
						<ul className={bem('nav-inner')}>
							{NAV_LIST.map((n) => (
								<li
									key={n.value}
									className={bem('nav-item', { active: n.value === nav })}
									onClick={() => {
										handleNavChange(n.value);
									}}
								>
									{n.label}
								</li>
							))}
						</ul>
					</div>
					<div className={bem('panel')}>
						<Tabs className={bem('prize-tab', { active: nav === 'prize' })} defaultActiveKey="coupon">
							<Tabs.Panel
								className={bem('prize-tab-panel')}
								key="coupon"
								title="优惠券"
								forceRender={false}
							>
								{renderCouponList()}
							</Tabs.Panel>
							<Tabs.Panel className={bem('prize-tab-panel')} key="card" title="卡牌">
								{renderCardList()}
							</Tabs.Panel>
							<Tabs.Panel className={bem('prize-tab-panel')} key="point" title="积分">
								{renderPointList()}
							</Tabs.Panel>
						</Tabs>
						<div className={bem('send-list', { active: nav === 'send' })}>{renderSendList()}</div>
					</div>
				</div>
			</GamePopup>
		);
	},
);

export default PrizePopup;
