import { Popup } from 'fnx-ui';
import { PopupProps } from 'fnx-ui/lib/popup';
import React from 'react';
import { createFC } from '../../utils/react-utils';
import imgShareTip from '../../assets/share-tip.png';
import './index.less';
import { classnames, createBEM } from '../../utils/class-utils';

const bem = createBEM('share-tip-popup');

const ShareTipPopup = createFC<PopupProps>('ShareTipPopup', ({ className, ...props }) => {
	return (
		<Popup
			{...props}
			className={classnames(bem(), className)}
			onClick={() => {
				props.onClose?.();
			}}
		>
			<img src={imgShareTip} />
		</Popup>
	);
});

export default ShareTipPopup;
