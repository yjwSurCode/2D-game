import { Dictionary } from '../../interface/index';
import React, { HTMLAttributes, ReactNode } from 'react';
import { classnames, createBEM } from '../../utils/class-utils';
import { createFC } from '../../utils/react-utils';
import imgActivity from './assets/error-empty-activity.png';
import imgCafeteria from './assets/error-empty-cafeteria.png';
import imgCards from './assets/error-empty-cards.png';
import imgCoupon from './assets/error-empty-coupon.png';
import imgDefault from './assets/error-empty-default.png';
import imgDevelopment from './assets/error-empty-development.png';
import imgDisconnected from './assets/error-empty-disconnected.png';
import imgInbox from './assets/error-empty-inbox.png';
import imgLicensePlate from './assets/error-empty-license-plate.png';
import imgLocation from './assets/error-empty-location.png';
import imgMalfunction from './assets/error-empty-malfunction.png';
import imgOrder from './assets/error-empty-order.png';
import imgShoppingCart from './assets/error-empty-shopping-cart.png';
import imgStore from './assets/error-empty-store.png';
import './index.less';

const TEXTURES: Dictionary<string> = {
	activity: imgActivity,
	cafeteria: imgCafeteria,
	cards: imgCards,
	coupon: imgCoupon,
	default: imgDefault,
	development: imgDevelopment,
	disconnected: imgDisconnected,
	inbox: imgInbox,
	'license-plate': imgLicensePlate,
	location: imgLocation,
	malfunction: imgMalfunction,
	order: imgOrder,
	'shopping-cart': imgShoppingCart,
	store: imgStore,
};

const VALID_STATUS_LIST = Object.keys(TEXTURES);

interface CProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
	image?: ReactNode;
	description?: ReactNode;
	filled?: boolean;
	status?: string;
}

const bem = createBEM('error-empty');

const ErrorEmpty = createFC<CProps>(
	'ErrorEmpty',
	({ className, image, description, filled, status = 'default', ...props }) => {
		const renderDescription = () => {
			if (!description) {
				return;
			}

			if (typeof description === 'string') {
				<div className={bem('description')}>
					{description.split(/\n/).map((desc, key) => {
						return <p key={key}>{desc}</p>;
					})}
				</div>;
			}

			return <div className={bem('description')}>{description}</div>;
		};

		return (
			<div className={classnames(bem({ filled }), className)} {...props}>
				<div className={bem('container')}>
					<div className={bem('image')}>
						{image || (
							<img src={VALID_STATUS_LIST.includes(status) ? TEXTURES[status] : TEXTURES['default']} />
						)}
					</div>
					{renderDescription()}
				</div>
			</div>
		);
	},
);

export default ErrorEmpty;
