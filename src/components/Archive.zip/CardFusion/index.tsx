// import { Dictionary } from "../../interface/index";
// import anime, { AnimeAnimParams, AnimeInstanceParams } from "animejs";
// import React, { useCallback, useEffect, useRef } from "react";
// import { useUnmountedRef } from "../../hooks/use-life-cycle";
// import { createBEM } from "../../utils/class-utils";
// import { createFC } from "../../utils/react-utils";
// import imgFusionBtn from "./assets/fusion-btn.png";
// import imgFusionCardCycle from "./assets/fusion-card-cycle.png";
// import imgFusionCardMask from "./assets/fusion-card-mask.png";
// import imgFusionCard from "./assets/fusion-card.png";
// import imgFusionCompleteTitle from "./assets/fusion-complete-title.png";
// import imgFusionHalo from "./assets/fusion-halo.png";
// import imgFusionIconBg from "./assets/fusion-icon-bg.png";
// import imgFusionIconMask from "./assets/fusion-icon-mask.png";
// import imgFusionIconRing from "./assets/fusion-icon-ring.png";
// import imgFusionIconText from "./assets/fusion-icon-text.png";
// import "./index.less";

// const bem = createBEM("card-fusion");

// interface CProps {
//   onReceive?: () => void;
// }

// export const CARD_FUSION_TEXTURES: Dictionary<string> = {
//   "fusion-btn": imgFusionBtn,
//   "fusion-card-cycle": imgFusionCardCycle,
//   "fusion-card": imgFusionCard,
//   "fusion-card-mask": imgFusionCardMask,
//   "fusion-complete-title": imgFusionCompleteTitle,
//   "fusion-halo": imgFusionHalo,
//   "fusion-icon-bg": imgFusionIconBg,
//   "fusion-icon-mask": imgFusionIconMask,
//   "fusion-icon-ring": imgFusionIconRing,
//   "fusion-icon-text": imgFusionIconText,
// };

// const CardFusion = createFC<CProps>("CardFusion", ({ onReceive }) => {
//   const cycleRef = useRef<HTMLImageElement>(null);
//   const haloRef = useRef<HTMLImageElement>(null);
//   const iconRef = useRef<HTMLDivElement>(null);
//   const iconBgRef = useRef<HTMLImageElement>(null);
//   const iconRingRef = useRef<HTMLImageElement>(null);
//   const iconMaskRef = useRef<HTMLImageElement>(null);
//   const titleRef = useRef<HTMLImageElement>(null);
//   const resultRef = useRef<HTMLDivElement>(null);
//   const cardRef = useRef<HTMLImageElement>(null);
//   const cardMaskRef = useRef<HTMLImageElement>(null);
//   const btnRef = useRef<HTMLAnchorElement>(null);

//   const unmounted = useUnmountedRef();

//   const clearList = useRef<Array<() => void>>([]);

//   useEffect(() => {
//     const clears = clearList.current;
//     return () => {
//       for (const clear of clears) {
//         clear();
//       }
//     };
//   }, []);

//   const animate = useCallback(
//     (params: AnimeInstanceParams | AnimeAnimParams): Promise<void> => {
//       return new Promise<void>((resolve) => {
//         let done = false;

//         if (unmounted.current) {
//           resolve();
//           return;
//         }

//         const animation = anime({
//           easing: "linear",
//           ...params,
//           complete: () => {
//             resolve();
//             done = true;
//           },
//         });

//         clearList.current.push(() => {
//           if (!done) {
//             animation.pause();
//           }
//         });
//       });
//     },
//     [unmounted]
//   );

//   const execute = useCallback(
//     (tasks: Array<() => any> | (() => any)) => {
//       for (const task of Array.isArray(tasks) ? tasks : [tasks]) {
//         if (!unmounted.current) {
//           task();
//         }
//       }
//     },
//     [unmounted]
//   );

//   useEffect(() => {
//     const cycle = cycleRef.current;
//     const halo = haloRef.current;
//     const icon = iconRef.current;
//     const iconBg = iconBgRef.current;
//     const iconRing = iconRingRef.current;
//     const iconMask = iconMaskRef.current;
//     const title = titleRef.current;
//     const result = resultRef.current;
//     const card = cardRef.current;
//     const cardMask = cardMaskRef.current;
//     const btn = btnRef.current;

//     if (
//       !cycle ||
//       !halo ||
//       !icon ||
//       !iconBg ||
//       !iconRing ||
//       !iconMask ||
//       !title ||
//       !result ||
//       !card ||
//       !cardMask ||
//       !btn
//     ) {
//       return;
//     }

//     const SPEED = 1;

//     const stage01 = () =>
//       Promise.all([
//         (async () => {
//           // 合成环旋转动画
//           await animate({
//             targets: iconRing,
//             rotate: {
//               value: 840,
//               duration: 2340 * SPEED,
//             },
//           });
//         })(),
//         (async () => {
//           // 卡牌围绕动画 - 初始化
//           execute(() => {
//             cycle.style.transform = `scale(2)`;
//             cycle.style.visibility = "visible";
//           });

//           // 卡牌围绕动画
//           await animate({
//             targets: cycleRef.current,
//             rotate: {
//               value: -45,
//               duration: 1000 * SPEED,
//             },
//             scale: [
//               {
//                 value: 1,
//                 duration: 170 * SPEED,
//               },
//               {
//                 value: 0.328,
//                 delay: 670 * SPEED,
//                 duration: 330 * SPEED,
//               },
//             ],
//           });

//           execute(() => {
//             cycle.style.visibility = "hidden"; // 隐藏卡牌围绕
//             halo.style.visibility = "visible"; // 显示合成光晕
//             halo.style.opacity = "0";
//           });

//           await Promise.all([
//             // 光晕旋转
//             animate({
//               targets: halo,
//               rotate: {
//                 value: 480,
//                 duration: 1340 * SPEED,
//               },
//               opacity: [
//                 {
//                   value: 1,
//                   duration: 100 * SPEED,
//                 },
//                 {
//                   value: 0,
//                   delay: 1140 * SPEED,
//                   duration: 100 * SPEED,
//                 },
//               ],
//             }),
//             // 隐藏图标
//             animate({
//               targets: icon,
//               opacity: {
//                 value: 0,
//                 delay: 1240 * SPEED,
//                 duration: 100 * SPEED,
//               },
//             }),
//             // 图标遮罩
//             animate({
//               targets: iconMask,
//               scale: [
//                 {
//                   value: 1.2,
//                   duration: 335 * SPEED,
//                 },
//                 {
//                   value: 1,
//                   duration: 335 * SPEED,
//                 },
//               ],
//               opacity: [
//                 {
//                   value: 1,
//                   duration: 335 * SPEED,
//                 },
//                 {
//                   value: 0,
//                   duration: 335 * SPEED,
//                 },
//               ],
//             }),
//             // 图标背景动画
//             animate({
//               targets: iconBg,
//               loop: 2,
//               scale: [
//                 {
//                   value: 1.2,
//                   duration: 335 * SPEED,
//                 },
//                 {
//                   value: 1,
//                   duration: 335 * SPEED,
//                 },
//               ],
//             }),
//           ]);
//         })(),
//       ]);

//     const stage02 = async () => {
//       execute(() => {
//         result.style.visibility = "visible";
//         cardMask.style.transform = "scale(0.5)";
//         card.style.transform = "scale(0.5)";
//       });

//       await Promise.all([
//         animate({
//           targets: card,
//           scale: [
//             {
//               value: 1.2,
//               duration: 170 * SPEED,
//             },
//             {
//               value: 1,
//               duration: 170 * SPEED,
//             },
//           ],
//         }),
//         animate({
//           targets: cardMask,
//           scale: [
//             {
//               value: 1.2,
//               duration: 170 * SPEED,
//             },
//             {
//               value: 2,
//               duration: 170 * SPEED,
//             },
//           ],
//           opacity: [
//             {
//               value: 1,
//               duration: 170 * SPEED,
//             },
//             {
//               value: 0,
//               duration: 170 * SPEED,
//             },
//           ],
//         }),
//       ]);

//       execute(() => {
//         title.style.opacity = "1";
//         btn.style.opacity = "1";
//       });

//       await animate({
//         targets: card,
//         loop: true,
//         translateY: [
//           {
//             value: -5,
//             duration: 170 * SPEED,
//           },
//           {
//             value: 5,
//             duration: 510 * SPEED,
//           },
//           {
//             value: 0,
//             duration: 170 * SPEED,
//           },
//         ],
//       });
//     };

//     (async () => {
//       await stage01();
//       await stage02();
//     })();
//   }, [animate, execute]);

//   return (
//     <div className={bem()}>
//       <img ref={cycleRef} className={bem("cycle")} src={imgFusionCardCycle} />
//       <img ref={haloRef} className={bem("halo")} src={imgFusionHalo} />
//       <div ref={iconRef} className={bem("icon")}>
//         <img ref={iconBgRef} src={imgFusionIconBg} />
//         <img src={imgFusionIconText} />
//         <img ref={iconRingRef} src={imgFusionIconRing} />
//         <img
//           className={bem("icon-mask")}
//           ref={iconMaskRef}
//           src={imgFusionIconMask}
//         />
//       </div>

//       <div ref={resultRef} className={bem("result")}>
//         <img
//           ref={titleRef}
//           className={bem("title")}
//           src={imgFusionCompleteTitle}
//         />
//         <div className={bem("card")}>
//           <img ref={cardRef} src={imgFusionCard} />
//           <img
//             className={bem("card-mask")}
//             ref={cardMaskRef}
//             src={imgFusionCardMask}
//           />
//         </div>
//         <a ref={btnRef} className={bem("btn")} onClick={onReceive}>
//           <img src={imgFusionBtn} />
//         </a>
//       </div>
//     </div>
//   );
// });

// export default CardFusion;
