import React from 'react';
import { Icon, Popup } from 'fnx-ui';
import { PopupProps } from 'fnx-ui/lib/popup';
import { classnames, createBEM } from '../../utils/class-utils';
import { createFC } from '../../utils/react-utils';
import imgGamePopupClose from '../../assets/game-popup-close.png';
import './index.less';
import { noop } from '../../utils/misc-utils';

const bem = createBEM('game-popup');

interface CProps extends PopupProps {
	title?: string;
}

const GamePopup = createFC<CProps>('GamePopup', ({ className, onClose = noop, title, children, ...props }) => {
	const handleClose = () => {
		onClose();
	};

	return (
		<Popup
			position="bottom"
			round
			overlayCloseable={true}
			{...props}
			onClose={handleClose}
			className={classnames(bem(), className)}
		>
			<div className={bem('content')}>
				<div className={bem('title')}>{title && <span>{title}</span>}</div>
				<div className={bem('close')} onClick={handleClose}>
					<img src={imgGamePopupClose} />
				</div>
				{children}
			</div>
		</Popup>
	);
});

export default GamePopup;
