import { Button } from 'fnx-ui';
import { PopupProps } from 'fnx-ui/lib/popup';
import { createBEM } from 'fnx-ui/lib/utils/namespace';
import React, { useMemo } from 'react';
import { classnames } from '../../utils/class-utils';
import { createFC } from '../../utils/react-utils';
import GamePopup from '../GamePopup';
import './index.less';

interface CProps extends PopupProps {
	ruleType?: 'image' | 'text';
	ruleText?: string;
	ruleImage?: string;
}

const bem = createBEM('rule-popup');

const RulePopup = createFC<CProps>('RulePopup', ({ className, style, ruleType, ruleImage, ruleText, ...props }) => {
	const ruleContent = useMemo(() => {
		let res: string[] = [];

		if (ruleType !== 'image') {
			res = ruleText?.split('\n') || [];
		}
		return res;
	}, [ruleText, ruleType]);

	return (
		<GamePopup
			{...props}
			title="活动规则"
			style={{ height: '80%', ...style }}
			className={classnames(bem(), className)}
		>
			<div className={bem('body')}>
				<div className={bem('rule')}>
					{ruleType === 'image' ? <img src={ruleImage} /> : ruleContent.map((r, idx) => <p key={idx}>{r}</p>)}
				</div>

				<div className={bem('footer')}>
					<Button
						shape="round"
						className={bem('footer-confirm')}
						color="linear-gradient(90deg, #FF4ACF 0%, #9D7AF6 100%)"
						onClick={props.onClose}
					>
						知道了
					</Button>
				</div>
			</div>
		</GamePopup>
	);
});

export default RulePopup;
